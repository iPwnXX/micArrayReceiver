## Notice
configuration settting in `config.json`.   
read mic array data, visualize their amplitude. 

## requirement
input `pip install -r requirements.txt` in terminal to install necessary packages.

## usage
input `python recv_data_main.py` in terminal.
